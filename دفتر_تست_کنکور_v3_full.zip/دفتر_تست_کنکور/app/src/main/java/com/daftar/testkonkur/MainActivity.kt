package com.daftar.testkonkur

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private data class TestRecord(
    val id: Long,
    val subject: String,
    val grade: String,
    val chapter: String,
    val source: String,
    val mode: String,
    val from: Int,
    val to: Int,
    val customNumbers: String,
    val hard: Boolean,
    val note: String,
    val createdAt: Long,
    val reviewAt: Long,
    val reviewStage: Int,
    val completed: Boolean
) {
    fun numbers(): List<Int> = when (mode) {
        "زوج" -> if (to < from) emptyList() else (from..to).filter { it % 2 == 0 }
        "فرد" -> if (to < from) emptyList() else (from..to).filter { it % 2 != 0 }
        "دستی" -> parseNumberList(customNumbers)
        else -> if (to < from) emptyList() else (from..to).toList()
    }.distinct().sorted()

    fun displayRange(): String = when (mode) {
        "دستی" -> customNumbers.ifBlank { "—" }
        else -> "$from تا $to"
    }

    fun selectionSummary(): String = when (mode) {
        "زوج" -> "زوج‌ها • ${numbers().size} تست"
        "فرد" -> "فردها • ${numbers().size} تست"
        "دستی" -> "دستی • ${numbers().size} تست"
        else -> "همه • ${numbers().size} تست"
    }
}

private fun normalizeDigits(value: String): String = buildString(value.length) {
    value.forEach { ch ->
        append(
            when (ch) {
                '۰' -> '0'; '۱' -> '1'; '۲' -> '2'; '۳' -> '3'; '۴' -> '4'
                '۵' -> '5'; '۶' -> '6'; '۷' -> '7'; '۸' -> '8'; '۹' -> '9'
                else -> ch
            }
        )
    }
}

private fun parseNumberList(raw: String): List<Int> {
    val cleaned = normalizeDigits(raw)
        .replace('،', ',')
        .replace('؛', ';')
        .replace("..", "-")
        .replace('–', '-')
        .replace('—', '-')
    return cleaned.split(',', ';', ' ', '\n', '\t')
        .flatMap { token ->
            if (token.isBlank()) return@flatMap emptyList()
            if ('-' in token) {
                val p = token.split('-', limit = 2)
                val a = p.getOrNull(0)?.trim()?.toIntOrNull()
                val b = p.getOrNull(1)?.trim()?.toIntOrNull()
                if (a != null && b != null && a > 0 && b >= a && b - a <= 10000) (a..b).toList() else emptyList()
            } else token.trim().toIntOrNull()?.takeIf { it > 0 }?.let(::listOf) ?: emptyList()
        }
        .distinct()
        .sorted()
}

private fun keyFor(r: TestRecord, n: Int): String =
    "${r.subject}|${r.grade}|${r.chapter}|${r.source.trim().ifBlank { "بدون منبع" }}|$n"

private class Store(context: Context) {
    private val prefs = context.getSharedPreferences("daftar_tests", Context.MODE_PRIVATE)

    fun load(): List<TestRecord> = runCatching {
        val arr = JSONArray(prefs.getString("records", "[]"))
        (0 until arr.length()).map { i ->
            val x = arr.getJSONObject(i)
            TestRecord(
                id = x.getLong("id"),
                subject = x.getString("subject"),
                grade = x.getString("grade"),
                chapter = x.getString("chapter"),
                source = x.optString("source"),
                mode = x.optString("mode", "همه"),
                from = x.optInt("from", 1),
                to = x.optInt("to", 1),
                customNumbers = x.optString("customNumbers", ""),
                hard = x.optBoolean("hard", false),
                note = x.optString("note", ""),
                createdAt = x.optLong("createdAt", i.toLong()),
                reviewAt = x.optLong("reviewAt", 0),
                reviewStage = x.optInt("reviewStage", 0),
                completed = x.optBoolean("completed", false)
            )
        }
    }.getOrDefault(emptyList())

    fun save(list: List<TestRecord>) {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("subject", r.subject)
                put("grade", r.grade)
                put("chapter", r.chapter)
                put("source", r.source)
                put("mode", r.mode)
                put("from", r.from)
                put("to", r.to)
                put("customNumbers", r.customNumbers)
                put("hard", r.hard)
                put("note", r.note)
                put("createdAt", r.createdAt)
                put("reviewAt", r.reviewAt)
                put("reviewStage", r.reviewStage)
                put("completed", r.completed)
            })
        }
        prefs.edit().putString("records", arr.toString()).apply()
    }

    fun exportJson(list: List<TestRecord>): String {
        val root = JSONObject().apply {
            put("app", "DaftarTestKonkur")
            put("version", 3)
            put("exportedAt", System.currentTimeMillis())
            put("records", JSONArray().apply {
                list.forEach { r ->
                    put(JSONObject().apply {
                        put("id", r.id); put("subject", r.subject); put("grade", r.grade); put("chapter", r.chapter)
                        put("source", r.source); put("mode", r.mode); put("from", r.from); put("to", r.to)
                        put("customNumbers", r.customNumbers); put("hard", r.hard); put("note", r.note)
                        put("createdAt", r.createdAt); put("reviewAt", r.reviewAt); put("reviewStage", r.reviewStage)
                        put("completed", r.completed)
                    })
                }
            })
        }
        return root.toString(2)
    }

    fun importJson(json: String): List<TestRecord> {
        val root = JSONObject(json)
        val arr = root.getJSONArray("records")
        return (0 until arr.length()).map { i ->
            val x = arr.getJSONObject(i)
            TestRecord(
                id = x.getLong("id"), subject = x.getString("subject"), grade = x.getString("grade"),
                chapter = x.getString("chapter"), source = x.optString("source"), mode = x.optString("mode", "همه"),
                from = x.optInt("from", 1), to = x.optInt("to", 1), customNumbers = x.optString("customNumbers", ""),
                hard = x.optBoolean("hard", false), note = x.optString("note", ""),
                createdAt = x.optLong("createdAt", System.currentTimeMillis()), reviewAt = x.optLong("reviewAt", 0),
                reviewStage = x.optInt("reviewStage", 0), completed = x.optBoolean("completed", false)
            )
        }
    }
}

class MainVM(private val store: Store) : ViewModel() {
    var records by mutableStateOf(store.load())
        private set

    val totalUniqueSolved: Int
        get() = records.flatMap { r -> r.numbers().map { n -> keyFor(r, n) } }.distinct().size

    val totalRawSolved: Int
        get() = records.sumOf { it.numbers().size }

    val openHardRecords: List<TestRecord>
        get() = records.filter { it.hard && !it.completed }.sortedBy { it.reviewAt }

    val openHardTests: Int
        get() = openHardRecords.flatMap { r -> r.numbers().map { n -> keyFor(r, n) } }.distinct().size

    val dueReviews: Int
        get() = openHardRecords.count { it.reviewAt > 0 && it.reviewAt <= System.currentTimeMillis() }

    fun uniqueAddedCount(newRecord: TestRecord, exceptId: Long? = null): Int {
        val existing = records.filter { exceptId == null || it.id != exceptId }
            .flatMap { r -> r.numbers().map { n -> keyFor(r, n) } }.toHashSet()
        return newRecord.numbers().map { n -> keyFor(newRecord, n) }.distinct().count { it !in existing }
    }

    fun add(r: TestRecord) { records = records + r; store.save(records) }
    fun update(r: TestRecord) { records = records.map { if (it.id == r.id) r else it }; store.save(records) }
    fun delete(id: Long) { records = records.filterNot { it.id == id }; store.save(records) }

    fun markReviewed(id: Long) {
        val now = System.currentTimeMillis()
        records = records.map { r ->
            if (r.id != id || !r.hard || r.completed) return@map r
            when (r.reviewStage) {
                0 -> r.copy(reviewAt = now + days(3), reviewStage = 1)
                1 -> r.copy(reviewAt = now + days(7), reviewStage = 2)
                2 -> r.copy(reviewAt = now + days(14), reviewStage = 3)
                3 -> r.copy(reviewAt = now + days(30), reviewStage = 4)
                else -> r.copy(reviewAt = 0, completed = true, reviewStage = 5)
            }
        }
        store.save(records)
    }

    fun exportJson(): String = store.exportJson(records)

    fun importJson(json: String): Result<Unit> = runCatching {
        val imported = store.importJson(json)
        records = imported
        store.save(records)
    }

    companion object { private fun days(n: Int) = n.toLong() * 24 * 60 * 60 * 1000 }
}

class MainVMFactory(private val store: Store) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = MainVM(store) as T
}

private val grades = listOf("دهم", "یازدهم", "دوازدهم")
private val subjectsByGrade = mapOf(
    "دهم" to listOf("ریاضی ۱", "هندسه ۱", "فیزیک ۱", "شیمی ۱"),
    "یازدهم" to listOf("حسابان ۱", "هندسه ۲", "آمار و احتمال", "فیزیک ۲", "شیمی ۲"),
    "دوازدهم" to listOf("حسابان ۲", "هندسه ۳", "گسسته", "فیزیک ۳", "شیمی ۳")
)
private val allSubjects = subjectsByGrade.values.flatten()
private val chapters = (1..12).map { "فصل $it" }
private const val DAY = 24L * 60 * 60 * 1000

private val AppDark = darkColorScheme(
    primary = Color(0xFF8AB4FF),
    onPrimary = Color(0xFF082554),
    secondary = Color(0xFF70D6C0),
    tertiary = Color(0xFFFFC56E),
    background = Color(0xFF0A0E14),
    surface = Color(0xFF111722),
    surfaceVariant = Color(0xFF1A2230),
    onSurface = Color(0xFFE9EEF7),
    onSurfaceVariant = Color(0xFFAEB8C8)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DaftarApp() }
    }
}

@Composable
fun DaftarApp() {
    val context = LocalContext.current
    val vm: MainVM = viewModel(factory = MainVMFactory(Store(context.applicationContext)))
    var tab by remember { mutableIntStateOf(0) }
    var selectedSubject by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<TestRecord?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var snackbar by remember { mutableStateOf("") }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(vm.exportJson().toByteArray(Charsets.UTF_8)) }
            snackbar = "پشتیبان با موفقیت ذخیره شد."
        }.onFailure { snackbar = "ذخیره پشتیبان ناموفق بود." }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) runCatching {
            val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("empty")
            vm.importJson(json).getOrThrow()
            snackbar = "اطلاعات بازیابی شد."
        }.onFailure { snackbar = "فایل پشتیبان معتبر نیست." }
    }

    MaterialTheme(colorScheme = AppDark) {
        androidx.compose.runtime.CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                floatingActionButton = {
                    FloatingActionButton(onClick = { editing = null; showAdd = true }, shape = RoundedCornerShape(18.dp)) { Text("+") }
                },
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        val items = listOf("خانه", "درس‌ها", "سخت‌ها", "آمار")
                        items.forEachIndexed { i, label ->
                            NavigationBarItem(selected = tab == i, onClick = { tab = i; if (i != 1) selectedSubject = null }, icon = { Text(if (i == 0) "⌂" else if (i == 1) "▦" else if (i == 2) "★" else "▤", fontSize = 18.sp) }, label = { Text(label) })
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when (tab) {
                        0 -> Home(vm, onAdd = { editing = null; showAdd = true }, onSubjects = { tab = 1 }, onHard = { tab = 2 })
                        1 -> if (selectedSubject == null) Subjects(vm) { selectedSubject = it } else SubjectDetail(vm, selectedSubject!!, onBack = { selectedSubject = null }, onAdd = { editing = null; showAdd = true }, onEdit = { editing = it; showAdd = true })
                        2 -> Hard(vm, onEdit = { editing = it; showAdd = true })
                        else -> Stats(vm, onExport = { exportLauncher.launch("دفتر-تست-پشتیبان.json") }, onImport = { importLauncher.launch(arrayOf("application/json", "text/plain")) })
                    }
                }
            }

            if (showAdd) {
                AddEditDialog(
                    initial = editing,
                    defaultSubject = selectedSubject ?: subjectsByGrade.getValue("دوازدهم").first(),
                    vm = vm,
                    onClose = { showAdd = false; editing = null },
                    onSaved = { count -> snackbar = "ثبت شد؛ $count تست جدید به آمار اضافه شد."; showAdd = false; editing = null }
                )
            }
            if (editing != null) {
                // Editing is opened through record cards, and the dialog is controlled above.
            }
            if (snackbar.isNotBlank()) {
                AlertDialog(onDismissRequest = { snackbar = "" }, title = { Text("دفتر تست") }, text = { Text(snackbar) }, confirmButton = { TextButton(onClick = { snackbar = "" }) { Text("باشه") } })
            }
        }
    }
}

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 18.dp, vertical = 18.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp), content = content
)

@Composable
private fun Home(vm: MainVM, onAdd: () -> Unit, onSubjects: () -> Unit, onHard: () -> Unit) {
    ScreenColumn {
        Text("دفتر تست", fontSize = 31.sp, fontWeight = FontWeight.ExtraBold)
        Text("ثبت دقیق • مرور هوشمند • آمار واقعی", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("تست یکتا", vm.totalUniqueSolved.toString(), Modifier.weight(1f))
            StatCard("سختِ باز", vm.openHardTests.toString(), Modifier.weight(1f))
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("مرور امروز", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(if (vm.dueReviews == 0) "امروز مرور سررسیدشده نداری." else "${vm.dueReviews} مورد برای مرور سررسید شده.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (vm.dueReviews > 0) AssistChip(onClick = onHard, label = { Text("مشاهده مرورها") })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onAdd, Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("＋ ثبت تست") }
            OutlinedButton(onClick = onSubjects, Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("درس‌ها") }
        }
        Text("پیشرفت بر اساس درس", fontSize = 19.sp, fontWeight = FontWeight.Bold)
        grades.forEach { grade ->
            val subjects = subjectsByGrade.getValue(grade)
            val gradeCount = vm.records.filter { it.grade == grade }.flatMap { r -> r.numbers().map { keyFor(r, it) } }.distinct().size
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text(grade, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("$gradeCount تست یکتا", color = MaterialTheme.colorScheme.primary) }
                    LinearProgressIndicator(progress = { (gradeCount.coerceAtMost(1000) / 1000f) }, Modifier.fillMaxWidth())
                    Text(subjects.joinToString(" • "), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(17.dp)) { Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(4.dp)); Text(value, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold) } }
}

@Composable
private fun Subjects(vm: MainVM, onSelect: (String) -> Unit) {
    ScreenColumn {
        Text("درس‌های تخصصی", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text("دهم تا دوازدهم، با ساختار جداگانه برای هر کتاب.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        grades.forEach { grade ->
            Text(grade, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            subjectsByGrade.getValue(grade).forEach { subject ->
                val count = vm.records.filter { it.subject == subject && it.grade == grade }.flatMap { r -> r.numbers().map { keyFor(r, it) } }.distinct().size
                Card(Modifier.fillMaxWidth().clickable { onSelect(subject) }, shape = RoundedCornerShape(19.dp)) {
                    Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(subject, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Text("$count تست یکتا", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Text("＋", fontSize = 25.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun SubjectDetail(vm: MainVM, subject: String, onBack: () -> Unit, onAdd: () -> Unit, onEdit: (TestRecord) -> Unit) {
    var query by remember { mutableStateOf("") }
    val grade = grades.firstOrNull { subject in subjectsByGrade.getValue(it) } ?: "دوازدهم"
    val data = vm.records.filter { it.subject == subject && (query.isBlank() || listOf(it.chapter, it.source, it.note).any { t -> t.contains(query, ignoreCase = true) }) }.sortedByDescending { it.createdAt }
    ScreenColumn {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("بازگشت") }
            Spacer(Modifier.width(4.dp))
            Column { Text(subject, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold); Text(grade, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }
        }
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("جستجو در فصل، منبع یا یادداشت") }, singleLine = true)
        Button(onClick = onAdd, Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Text("＋ ثبت تست برای این درس") }
        if (data.isEmpty()) Text("هنوز رکوردی برای این درس ثبت نشده.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(data, key = { it.id }) { r -> RecordCard(r, vm, showReview = r.hard && !r.completed, onEdit = { onEdit(r) }) }
        }
    }
}

@Composable
private fun RecordCard(r: TestRecord, vm: MainVM, showReview: Boolean, onEdit: () -> Unit = {}) {
    var confirmDelete by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${r.grade} • ${r.chapter}", fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                if (r.hard) Text("★", color = MaterialTheme.colorScheme.tertiary, fontSize = 20.sp)
            }
            Text("تست ${r.displayRange()} • ${r.selectionSummary()}")
            if (r.source.isNotBlank()) Text("منبع: ${r.source}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (r.note.isNotBlank()) Text("یادداشت: ${r.note}")
            if (r.hard && !r.completed) {
                Text("مرور ${r.reviewStage}/5 • ${reviewLabel(r.reviewAt)}", color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp)
            } else if (r.hard) Text("مرور کامل شده", color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (showReview) OutlinedButton(onClick = { vm.markReviewed(r.id) }) { Text("مرور شد") }
                TextButton(onClick = onEdit) { Text("ویرایش") }
                TextButton(onClick = { confirmDelete = true }) { Text("حذف") }
            }
        }
    }
    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("حذف رکورد؟") }, text = { Text("این ثبت از دفتر تست حذف می‌شود.") }, confirmButton = { Button(onClick = { vm.delete(r.id); confirmDelete = false }) { Text("حذف") } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("لغو") } })
}

@Composable
private fun Hard(vm: MainVM, onEdit: (TestRecord) -> Unit) {
    var onlyDue by remember { mutableStateOf(false) }
    val list = if (onlyDue) vm.openHardRecords.filter { it.reviewAt <= System.currentTimeMillis() } else vm.openHardRecords
    ScreenColumn {
        Text("تست‌های سخت", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text("مرور مرحله‌ای: ۱ روز، ۳ روز، ۷ روز، ۱۴ روز و ۳۰ روز.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(onlyDue, { onlyDue = it })
            Text("فقط سررسیدها")
            Spacer(Modifier.weight(1f))
            Text("${vm.openHardTests} تست باز", color = MaterialTheme.colorScheme.primary)
        }
        if (list.isEmpty()) Text(if (onlyDue) "مورد سررسیدشده‌ای نداری." else "فعلاً تست سختی ثبت نشده.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(list, key = { it.id }) { RecordCard(it, vm, showReview = true, onEdit = { onEdit(it) }) } }
    }
}

@Composable
private fun Stats(vm: MainVM, onExport: () -> Unit, onImport: () -> Unit) {
    ScreenColumn {
        Text("آمار و پشتیبان", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text("تست‌های تکراری در شمارش یکتا نمی‌شوند مگر اینکه منبع متفاوت باشد.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        StatCard("تست‌های یکتا", vm.totalUniqueSolved.toString(), Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("ثبت‌های خام", vm.totalRawSolved.toString(), Modifier.weight(1f))
            StatCard("مرورهای امروز", vm.dueReviews.toString(), Modifier.weight(1f))
        }
        grades.forEach { grade ->
            val count = vm.records.filter { it.grade == grade }.flatMap { r -> r.numbers().map { keyFor(r, it) } }.distinct().size
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Text(grade, fontWeight = FontWeight.Bold); Text("$count تست یکتا", color = MaterialTheme.colorScheme.primary) } }
        }
        Divider()
        Text("پشتیبان اطلاعات", fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text("برای تعویض گوشی یا نصب مجدد، اول خروجی بگیر و بعد فایل را بازیابی کن.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onExport, Modifier.weight(1f)) { Text("خروجی JSON") }
            OutlinedButton(onClick = onImport, Modifier.weight(1f)) { Text("بازیابی JSON") }
        }
        Text("درس‌ها", fontSize = 19.sp, fontWeight = FontWeight.Bold)
        allSubjects.forEach { subject ->
            val count = vm.records.filter { it.subject == subject }.flatMap { r -> r.numbers().map { keyFor(r, it) } }.distinct().size
            if (count > 0) Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(subject); Spacer(Modifier.weight(1f)); Text("$count") }
        }
    }
}

@Composable
private fun AddEditDialog(
    initial: TestRecord?,
    defaultSubject: String,
    vm: MainVM,
    onClose: () -> Unit,
    onSaved: (Int) -> Unit
) {
    val initialGrade = initial?.grade ?: grades.firstOrNull { defaultSubject in subjectsByGrade.getValue(it) } ?: "دوازدهم"
    var grade by remember { mutableStateOf(initialGrade) }
    var subject by remember { mutableStateOf(initial?.subject ?: defaultSubject) }
    var chapter by remember { mutableStateOf(initial?.chapter ?: "فصل ۱") }
    var source by remember { mutableStateOf(initial?.source ?: "") }
    var mode by remember { mutableStateOf(initial?.mode ?: "همه") }
    var from by remember { mutableStateOf(initial?.from?.toString() ?: "") }
    var to by remember { mutableStateOf(initial?.to?.toString() ?: "") }
    var custom by remember { mutableStateOf(initial?.customNumbers ?: "") }
    var hard by remember { mutableStateOf(initial?.hard ?: false) }
    var note by remember { mutableStateOf(initial?.note ?: "") }
    var error by remember { mutableStateOf("") }

    val subjectOptions = subjectsByGrade.getValue(grade)
    val currentSubject = if (subject in subjectOptions) subject else subjectOptions.first()

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (initial == null) "ثبت تست جدید" else "ویرایش ثبت") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.heightIn(max = 560.dp)) {
                item { Dropdown("پایه", grade, grades) { grade = it } }
                item { Dropdown("درس", currentSubject, subjectOptions) { subject = it } }
                item { Dropdown("فصل", chapter, chapters) { chapter = it } }
                item { OutlinedTextField(source, { source = it }, Modifier.fillMaxWidth(), label = { Text("منبع / کتاب") }, singleLine = true) }
                item { Dropdown("نحوه انتخاب تست", mode, listOf("همه", "زوج", "فرد", "دستی")) { mode = it } }
                if (mode == "دستی") {
                    item { OutlinedTextField(custom, { custom = it }, Modifier.fillMaxWidth(), label = { Text("شماره تست‌ها") }, supportingText = { Text("مثال: 1,4,7-12,20") }) }
                } else {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(from, { from = normalizeDigits(it).filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("از") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                            OutlinedTextField(to, { to = normalizeDigits(it).filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("تا") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        }
                    }
                }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(hard, { hard = it }); Text("این تست‌ها سخت‌اند و باید مرور شوند") } }
                if (hard) item { OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("دلیل سخت بودن / نکته") }, minLines = 2) }
                if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val normalizedFrom = normalizeDigits(from).toIntOrNull()
                val normalizedTo = normalizeDigits(to).toIntOrNull()
                val nums = if (mode == "دستی") parseNumberList(custom) else if (normalizedFrom != null && normalizedTo != null && normalizedTo >= normalizedFrom && normalizedFrom > 0) {
                    when (mode) { "زوج" -> (normalizedFrom..normalizedTo).filter { it % 2 == 0 }; "فرد" -> (normalizedFrom..normalizedTo).filter { it % 2 != 0 }; else -> (normalizedFrom..normalizedTo).toList() }
                } else emptyList()
                if (nums.isEmpty()) { error = "شماره تست‌ها را درست وارد کن."; return@Button }
                val now = System.currentTimeMillis()
                val record = TestRecord(
                    id = initial?.id ?: now,
                    subject = currentSubject,
                    grade = grade,
                    chapter = chapter,
                    source = source.trim(),
                    mode = mode,
                    from = normalizedFrom ?: nums.first(),
                    to = normalizedTo ?: nums.last(),
                    customNumbers = if (mode == "دستی") normalizeDigits(custom).trim() else "",
                    hard = hard,
                    note = note.trim(),
                    createdAt = initial?.createdAt ?: now,
                    reviewAt = when {
                        !hard -> 0
                        initial == null -> now + DAY
                        !initial.hard || initial.completed -> now + DAY
                        else -> initial.reviewAt
                    },
                    reviewStage = when {
                        !hard -> 0
                        initial == null -> 0
                        !initial.hard || initial.completed -> 0
                        else -> initial.reviewStage
                    },
                    completed = if (!hard) false else if (initial == null) false else if (!initial.hard || initial.completed) false else initial.completed
                )
                val uniqueAdded = vm.uniqueAddedCount(record, initial?.id)
                if (initial == null) vm.add(record) else vm.update(record)
                onSaved(uniqueAdded)
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("لغو") } }
    )
}

@Composable
private fun Dropdown(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("$label: $value") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); open = false }) }
        }
    }
}

private fun reviewLabel(timestamp: Long): String {
    if (timestamp <= 0) return "—"
    val now = System.currentTimeMillis()
    val prefix = if (timestamp <= now) "سررسید شده" else "موعد:"
    val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(timestamp))
    return "$prefix $date"
}
