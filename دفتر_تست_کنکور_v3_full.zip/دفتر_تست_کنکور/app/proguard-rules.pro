# Project-specific R8 rules.
# No custom rules are required for this app.
